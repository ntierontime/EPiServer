//>>built
define("dojo/cldr/nls/zh-hk/number",{"currencyFormat":"¤#,##0.00","decimalFormat-short":"000T","nan":"非數值"});